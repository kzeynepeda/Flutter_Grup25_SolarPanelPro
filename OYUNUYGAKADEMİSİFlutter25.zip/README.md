# GüneşPlan Pro
Teknik bilgiye ihtiyacınız olmadan ne kadar enerji üretebileceğini öğrenebielec olan
kullanıcıların kendi çatılarının veya tarlalarının güneş enerjisi potansiyelini değerlendirmelerine olanak tanıyan bu uygulama,
yerel konum bilgileri ve kullanıcı girdileriyle özelleştirilmiş enerji üretim raporları sunacak.
Ayrıca Yapay zeka entegresi ile Uygulama botu Rapordan panel ve güç miktarı bilgi ve verileri 
alacak ona göre kullanıcıya kullanabileceği panelleri önerecek.


## Geliştiriciler

EBRA NUR ZUREL
MEDYA DORAN
ZEYNEP EDA KARA
AHMET TALHA AKYOL



